// trae todo lo que tiene react para que realmente funcione 
import React from 'react';
// imr y ccc
// React.Component, para que herede todo lo que tiene el componente
class ListarCurso extends React.Component {
    constructor(props) {
        super(props);
        // aqui estado en memoria
        this.state = {
            // declarando json
            datosCargados: false,
            // arreglo vacio para traer datos
            datosCursos: [],
        }
    }
    cargarDatos() {
        fetch("https://paginas-web-cr.com/ApiPHP/apis/ListaCurso.php")//url de peticion de datos
            .then(respuesta => respuesta.json())//recibe los datos en formato json
            .then((datosrepuesta) => {
                // cargo en el estado que si trae un estado y adicional datos en el arreglo
                // el set es para guardar, el otro solo para declarar
                this.setState({datosCargados:true, datosCursos:datosrepuesta.data})
                console.log(datosrepuesta.data);
            })
            .catch(console.log)//muestra errores
    }
    eliminar(id){
        console.log(id);
    }

    editar(objeto){
        console.log(objeto);
    }
    // invocar como el document ready
    componentDidMount(){
        this.cargarDatos();
    }

    render() {
        // aqui pasa a ser una constante
        const { datosCargados, datosCursos } = this.state
        return (
            <div className='container'>
                <h1>Listar Curso</h1>
                <div className="table-responsive">
                    <table className="table table-primary">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Nombre</th>
                                <th>Descripcion</th>
                                <th>Tiempo</th>
                                <th>Usuario</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                        {/* puedo mapear los datos, traerlos */}
                        {
                            datosCursos.map(
                                (datosExtraidos)=>
                                <tr key={datosExtraidos.id} className="table-primary" >
                                <td scope="row">${datosExtraidos.id}</td>
                                <td>{datosExtraidos.nombre}</td>
                                <td>{datosExtraidos.descripcion}</td>
                                <td>{datosExtraidos.tiempo}</td>
                                <td>{datosExtraidos.usuario}</td>
    
                                <td>
                                  <a name="" id="" className="btn btn-danger" onClick={()=>this.eliminar(datosExtraidos.id)} role="button">Borrar</a>
                                  <a name="" id="" className="btn btn-primary" onClick={()=>this.editar(datosExtraidos)} role="button">Editar</a>
                                </td>
                            </tr>
                            )
                        }
                        </tbody>
                    </table>
                </div>

            </div>
        );
    }
}

export default ListarCurso;