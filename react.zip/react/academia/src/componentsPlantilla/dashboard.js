// trae todo lo que tiene react para que realmente funcione 
import React from 'react';
// imr y ccc
// React.Component, para que herede todo lo que tiene el componente
class Dashboard extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            datosCargados: false,
            datosCursos: [],
        }
    }
    render() {
        const { datosCargados, datosCursos } = this.state
        return (
            <div className='container'>
                <h1>Dashboard</h1>
            </div>
        );
    }
}

export default Dashboard;